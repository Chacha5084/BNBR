#include "../include/serveur.h"

int main() {
    menu_accueil();
}

void menu_accueil(){

    init_ncurses();

    int choix = 0;

    while (1) {
        clear();

        attron(A_BOLD);
        attron(COLOR_PAIR(3));
        printw("Bienvenue dans le jeu de la bataille navale\n");
        printw("Que souhaitez vous faire ?\n\n");
        attroff(COLOR_PAIR(3));
        attroff(A_BOLD);

        // Affichage menu d'accueil
        switch (choix)
        {
            case 0:
                attron(COLOR_PAIR(2));
                printw("Parametrer une partie\n");
                attroff(COLOR_PAIR(2));

                printw("Quitter le programme\n");
            break;

            case 1:
                printw("Parametrer une partie\n");

                attron(COLOR_PAIR(1));
                printw("Quitter le programme\n");
                attroff(COLOR_PAIR(1));
            break;
            
            default:
                choix = 0;
                attron(COLOR_PAIR(2));
                printw("Parametrer une partie\n");
                attroff(COLOR_PAIR(2));

                printw("Quitter le programme\n");
            break;
        }

        refresh();

        // Gestion des touches
        int c = getch();
        switch (c) {

            // Fleche du haut 
            case KEY_UP:
                if (choix == 1)
                    choix --;
                break;

            // Fleche du bas
            case KEY_DOWN:

                if (choix == 0)
                    choix ++;
                break;

            // Touche entrée
            case 10:

                switch (choix) {
                    // Choix de création de partie
                    case 0:
                        menu_parametrage_game();
                        break;

                    // Choix de quitter    
                    case 1:
                        endwin();
                        exit(0);    
                        break;

                    // Choix inconnu
                    default:
                        // On remet le choix à 0
                        choix = 0;
                        break;
                    }

                break;
        }
    }

    endwin();
}

void menu_parametrage_game(){

    int parametre = 0;
    game_t game = init_game();

    while (1) {
        clear();

        // Paramétrage de la partie
        attron(COLOR_PAIR(3));
        attron(A_BOLD);
        printw("Parametrage de la partie                                           \n\n");
        attroff(COLOR_PAIR(3));
        attroff(A_BOLD);

        printw("Nombre de joueur :              <");
        if (parametre == 0)
            attron(A_REVERSE);
        printw("  %d  ", game.maxJoueur);
        attroff(A_REVERSE);
        printw(">\n");


        printw("Taille du plateau :             <");
        if (parametre == 1)
            attron(A_REVERSE);
        printw("  %d  ", game.taillePlateau);
        attroff(A_REVERSE);
        printw(">\n");

        printw("Taille des bateaux :            <");
        if (parametre == 2)
            attron(A_REVERSE);
        printw("  %d  ", game.tailleBateau);
        attroff(A_REVERSE);
        printw(">\n");

        printw("Temps pour jouer en seconde :   <");
        if (parametre == 3)
            attron(A_REVERSE);
        printw("  %d  ", game.timeout);
        attroff(A_REVERSE);
        printw(">\n");

        printw("\n---------------------------------------------------------------\n\n");

        attron(COLOR_PAIR(4));
        printw("Utilisez les touches bas et haut pour naviguer                    \n");
        printw("Utilisez les touches gauche et droite pour incrémenter la valeur  \n");
        printw("Appuyez sur la touche 'Entrée' pour valider vos parametres        \n");
        printw("Appuyez sur la touche 'q' pour revenir au menu principal          \n");
        attroff(COLOR_PAIR(4));

        printw("\n----------------------------------------------------------------\n\n");

        refresh();

        // Gestion des touches
        int c = getch();
        switch (c) {

            // Fleche du haut 
            case KEY_UP:

                if (parametre > 0)
                    parametre--;
                break;

            // Fleche du bas
            case KEY_DOWN:

                if (parametre < 3)
                    parametre ++;
                break;

            // Fleche du gauche 
            case KEY_LEFT:                
                switch (parametre)
                {
                case 0:
                    if (game.maxJoueur > 2)
                        game.maxJoueur--;
                    break;

                case 1:
                    if (game.taillePlateau > 10)
                        game.taillePlateau--;
                    break;
                
                case 2:
                    if (game.tailleBateau > 2)
                        game.tailleBateau--;
                    break;

                case 3:
                    if (game.timeout > 5)
                        game.timeout--;
                    break;
                }

                break;
            // Fleche du droit
            case KEY_RIGHT:
                switch (parametre)
                {
                case 0:
                    if (game.maxJoueur < MAX_PLAYER)
                        game.maxJoueur ++;
                    break;

                case 1:
                    if (game.taillePlateau < MAX_BOARD_SIZE)
                        game.taillePlateau ++;
                    break;
                
                case 2:
                    if (game.tailleBateau < MAX_BOAT_SIZE)
                        game.tailleBateau ++;
                    break;

                case 3:
                        game.timeout ++;
                    break;
                }
                break;    

            // Touche entrée
            case 10:
                // Lancement de l'attente des personnes
                attente_joueur(game);
                break;
        }
    }
}

void affichage_attente_joueur(game_t game){
    clear();

    // Affichage des infos de la partie
    attron(COLOR_PAIR(3));
    attron(A_BOLD);
    printw("Attente des joueurs\n\n");
    attroff(COLOR_PAIR(3));
    attroff(A_BOLD);

    printw("Nombre de joueur : %d\n", game.maxJoueur);
    printw("Taille du plateau : %d\n", game.taillePlateau);
    printw("Taille des bateaux : %d\n", game.tailleBateau);
    printw("Temps pour jouer en seconde : %d\n", game.timeout);

    printw("\n\n");

    // Affichage des joueurs
    printw("Liste des joueurs connectés: \n");
    for (int i = 0; i <= game.nbJoueur; i++)
    {
        printw("%s\n", game.players[i].pseudo);
    }
    printw(" %d / %d \n\n", game.nbJoueur, game.maxJoueur);

    printw("Enter pour lancer la partie\n");
    printw("Appuyez sur la touche 'q' pour revenir au menu principal\n");

    refresh();
}

void attente_joueur(game_t game){
    // Création de la socket d'ecoute : 
    socket_t server_socket = creerSocketEcoute("127.0.0.1", 8080);

    // Mémoire partagée
    int shmid;
    key_t key = 1234;
    game_t *shared_game;

    if ((shmid = shmget(key, sizeof(game_t), IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(EXIT_FAILURE);
    }

    if ((shared_game = shmat(shmid, NULL, 0)) == (game_t *) -1) {
        perror("shmat");
        exit(EXIT_FAILURE);
    }

    *shared_game = game;
    shared_game->nbJoueur = 0;
    shared_game->etat = 0;

    // Fork pour la gestion des connexions
    int pid = fork();

    // Erreur du fork
    if (pid < 0 ){
        perror("Erreur fork");
        exit(1);
    } 
    // Processus fils
    else if (pid == 0){
        // Gestion des connexions
        while(1){
            // On vérifie si le nombre de joueur est atteint
            if (shared_game->nbJoueur == shared_game->maxJoueur){
                // On quitte la boucle
                while(shared_game->etat == 0){
                    sleep(1);
                }
                break;
            }

            // On attend une connexion
            socket_t client_socket = accepterClt(server_socket);            
            
            // Erreur de client socket
            if (client_socket.fd == -1){
                perror("Erreur accepterClt");
            } else {

                // La partie est déja lancée
                if (shared_game->etat == 1){

                    req_t requete = format_req(-1, "nok", "La Partie est déja commencée\n");
                    envoyer(&client_socket, &requete, serial_req);
                    close(client_socket.fd);
                    break;
                    
                }

                // On connecte le client.
                else {

                    // On envoie une req de pseudo  au client
                    // TODO mettre en place la structure de message
                    req_t requete = format_req(0, "ok", " ");
                    envoyer(&client_socket, &requete, serial_req);

                    // On récupère le pseudo du joueur
                    req_t reponse;
                    recevoir(&client_socket, &reponse, unserial_req);

                    if (reponse.id == 1){
                        printw("Pseudo du joueur : %s\n", reponse.infos);
                        // On récupère le pseudo du joueur
                        strcpy(shared_game->players[shared_game->nbJoueur].pseudo, reponse.infos);
                        shared_game->players[shared_game->nbJoueur].socket = client_socket;
                        shared_game->players[shared_game->nbJoueur].id = shared_game->nbJoueur;
                        shared_game->nbJoueur++;

                        envoyer(&client_socket, &requete, serial_req);
                    } else {
                        // On envoie un message d'erreur
                        req_t requete = format_req(-1, "nok", "Erreur de connexion\n");
                        envoyer(&client_socket, &requete, serial_req);
                        close(client_socket.fd);
                    }
                  
                }
            
            }

        }

        close(server_socket.fd);
        
        while(shared_game->etat == 1){
            sleep(5);
        }
        exit(0);
    }
    
    // Processus père
    else {

        int flag = 0;
        int i = 0;
        timeout(1000);

        while(flag == 0){
            // Affichage des infos de la partie
            affichage_attente_joueur(*shared_game);
            printw("Getch... %d\n", i);
            i++;
            // Gestion des touches
            printw("Getch... %d\n", flag);
            refresh();
            int c = getch();
            switch (c)
            {
            case 'q':
                return;
                break;
            
            case 10:
                // Lancement de la partie
                // Fermeture de la socket d'ecoute
                shared_game->etat = 1;
                flag = 1;
                break;
            }
                        // Gestion des touches
            printw("Getch... %d\n", flag);
            refresh();
        }
    }

    timeout(-1); 

    lancement_partie(shared_game);
}

void lancement_partie(game_t *game){

    clear();
    printw("Lancement de la partie\n");
    refresh();

    // on envoie les infos de partie
    printw("Boucle envoie des infos : \n");
    for (int i = 0; i < game->nbJoueur; i++){
        printw("i = %d \n",i);
        refresh();
        envoyer_infos_partie(game, &game->players[i].socket);
    }

    for (int i = 0; i < game->nbJoueur; i++){
        recevoir_bateaux(game, &game->players[i]);
    }

    while(1){

        for (int i = 1; i <= game->nbJoueur; i++){
            envoyer_plateau(game->plateau, &game->players[i].socket);
        }

        for (int i = 0; i < game->nbJoueur; i++){
            recevoir_tir(game, &game->players[i]);
        }

        verifier_fin_partie(game);
    }
}

void verifier_fin_partie(game_t *game){
    
    int nbBateau = game->plateau.nbBateau;
    int nbBateauCoule = 0;
    int flag = 0;

    // Pour chaque batteau
    for (int i = 0; i < nbBateau; i++){
        flag = 0;

        // Pour chaque cellule du bateau
        for (int j = 0; j < game->plateau.bateaux[i].taille; j++){
            // On verifie si elles sont toutes hit
            if (game->plateau.bateaux[i].cell[j].status != HIT_SHOT){
                flag = 1;
            }
        }
        if (flag == 0){
            nbBateauCoule++;
        }
    }

    if (nbBateauCoule == nbBateau){
        game->etat = 0;
    } else if (nbBateauCoule == nbBateau - 1){
        game->etat = 2;{
            for (int i = 0; i < game->nbJoueur; i++){
                req_t requete = format_req(6, "fin", " ");
                envoyer(&game->players[i].socket, &requete, serial_req);
            }
        }
    }
}

/** Reception */
void recevoir_tir(game_t *game, client_t *client){

    req_t reponse;
    recevoir(&client->socket, &reponse, unserial_req);

    req_t requete = format_req(0, "ok", " ");
    envoyer(&client->socket, &requete, serial_req);

    if (reponse.id == 5){
        // On récupère les coordonnées du tir
        int x, y;
        sscanf(reponse.infos, "%d;%d", &x, &y);

        // On vérifie si le tir est valide
        if (x >= 0 && x < game->taillePlateau && y >= 0 && y < game->taillePlateau){
            // On vérifie si le tir est un touché
            if (game->plateau.cell[x][y].status == BOAT){
                game->plateau.cell[x][y].status = HIT_SHOT;
                tirer_bateau(x,y,&game->plateau, game->plateau.nbBateau);
            } else {
                game->plateau.cell[x][y].status = MISSED_SHOT;
            }
        }
    }
}

void tirer_bateau(int x, int y, board_t *board, int nbBateau){
    for (int i = 0; i < nbBateau; i++){
        for (int j = 0; j < board->bateaux[i].taille; j++){
            if (board->bateaux[i].cell[j].x == x && board->bateaux[i].cell[j].y == y){
                board->bateaux[i].cell[j].status = HIT_SHOT;
            }
        }
    }
}

void recevoir_bateaux(game_t *game, client_t *client){

    req_t requete = format_req(3, "bateaux", " ");
    envoyer(&client->socket, &requete, serial_req);

    req_t reponse;
    recevoir(&client->socket, &reponse, unserial_req);

    if (reponse.id == 3){
        // On récupère les bateaux
        char *bateaux = reponse.infos;

        int x, y, taille;
        char direction;

        // Utilisation de sscanf pour extraire les paramètres
        // x;y;direction
        sscanf(bateaux, "%d;%d;%c", &x, &y, &direction);

        // On place le bateau
        placer_bateau(&game->plateau, client->id, game->tailleBateau, x, y, direction);
    }
}

void placer_bateau(board_t *board, int id, int taille, int x, int y, char direction){

    if (direction == 'h'){

        for (int i = 0; i < taille; i++){
            board->bateaux[board->nbBateau].taille = taille;
            board->bateaux[board->nbBateau].cell[i].x = x;
            board->bateaux[board->nbBateau].cell[i].y = y - i;
            board->cell[x][y - i].status = BOAT;
        }

    } else if (direction == 'b'){

        for (int i = 0; i < taille; i++){
            board->bateaux[board->nbBateau].taille = taille;
            board->bateaux[board->nbBateau].cell[i].x = x;
            board->bateaux[board->nbBateau].cell[i].y = y + i;
            board->cell[x][y + i].status = BOAT;
        }

    } else if (direction == 'g'){

        for (int i = 0; i < taille; i++){
            board->bateaux[board->nbBateau].taille = taille;
            board->bateaux[board->nbBateau].cell[i].x = x - 1;
            board->bateaux[board->nbBateau].cell[i].y = y;
            board->cell[x - i][y].status = BOAT;
        }

    } else if (direction == 'd'){

        for (int i = 0; i < taille; i++){
            board->bateaux[board->nbBateau].taille = taille;
            board->bateaux[board->nbBateau].cell[i].x = x + 1;
            board->bateaux[board->nbBateau].cell[i].y = y;
            board->cell[x - i][y].status = BOAT;
        }

    }

}


/** Fonctionnalité d'envoie */
void envoyer_infos_partie(game_t * game, socket_t* socket_client){

    char infos[100];
    sprintf(infos, "%d;%d;%d;%d", game->nbJoueur, game->taillePlateau, game->tailleBateau, game->timeout);

    req_t req = format_req(4, "infos", infos);
    envoyer(socket_client, &req ,serial_req);
}

void envoyer_plateau(board_t board, socket_t* socket_client){

    int nbCases = MAX_BOARD_SIZE * MAX_BOARD_SIZE;
    char plateau[nbCases];

    for(int i = 0; i < MAX_BOARD_SIZE ; i++){
        for(int j = 0; j< MAX_BOARD_SIZE ; j++){
            switch (board.cell[j][i].status)
            {
                case MISSED_SHOT:
                    strcat(plateau,"0");
                    break;
                case HIT_SHOT:
                    strcat(plateau,"1");
                    break;
                case EMPTY:
                    strcat(plateau,"3");
                    break;
                case BOAT:
                    strcat(plateau,"3");
                    break;
            }
        }
    }

    req_t req = format_req(2,"plateau",plateau);
    envoyer(socket_client, &req ,serial_req);
}


/**  Fonctionnalités d'init */

void init_ncurses(){
    initscr();
    keypad(stdscr, TRUE); // Activer la prise en charge des touches spéciales
    start_color(); // Activer les couleurs
    curs_set(0); // Masquer le curseur
    noecho(); // Désactiver l'affichage des caractères saisis
    cbreak(); // Désactiver la mise en mémoire tampon de ligne


    // Définition des couleurs
    init_pair(1, COLOR_BLACK, COLOR_RED); // Texte rouge sur fond noir
    init_pair(2, COLOR_WHITE, COLOR_GREEN); // Texte rouge sur fond noir
    init_pair(3, COLOR_WHITE, COLOR_MAGENTA); // Texte rouge sur fond noir
    
    init_pair(4, COLOR_WHITE, COLOR_CYAN); // Texte rouge sur fond noir
}

game_t init_game(){
    game_t game;

    game.maxJoueur = 2;
    game.taillePlateau = 10;
    game.tailleBateau = 5;
    game.timeout = 30;
    
    game.nbJoueur = 0;
    game.etat = 0;

    return game;
}


//** Fonctionnalités de requete **//

req_t format_req(int id, char *nom, char *infos){
    req_t req;
    req.id = id;
    strncpy(req.nom, nom, sizeof(req.nom) - 1);
    strncpy(req.infos, infos, sizeof(req.infos) - 1);
    return req;
}

void serial_req(generic quoi, generic buff){
    req_t *req = (req_t *)quoi;
    sprintf(buff, "%d;%s;%s", req->id, req->nom, req->infos);
}

void unserial_req(generic buff, generic quoi){
    // Cast du paramètre quoi en pointeur vers une structure req_t
    req_t *req = (req_t *)quoi;

    // String de la requête
    char *str_req = (char *)buff;

    // Désérialisation de la requête
    sscanf(str_req, "%d;%99[^;];%999s", &req->id, req->nom, req->infos);
}
