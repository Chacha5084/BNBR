/**
 *	@file		server.c
 *	@brief		Code source du serveur
 *	@author		Deroubaix & Houplain
 *	@date		08/04/2024
 *	@version	1.5
 */

#include "../include/serveur.h"


/**********************************************************/
// Variable globale 
/**********************************************************/
char pseudo[50];

req_t format_req(int id, char *nom, char *infos);
void serial_req(generic quoi, generic buff);
void unserial_req(generic buff, generic quoi);

/**********************************************************/
// MAIN du programme
/**********************************************************/

int main(int argc, char *argv[]){
    buffer_t buffer;
    char adresse[16];
    int port;


    if (argc == 3) {
        strncpy(adresse, argv[1], 16 - 1);
        adresse[16 - 1] = '\0';
        port = atoi(argv[2]);
    } else {
        strncpy(adresse, "127.0.0.1", 16 - 1);
        adresse[16 - 1] = '\0';
        port = 8080;
    }

    printf("Bonjour, en attente de connexion au serveur\n\n");

    socket_t client_socket = connecterClt2Srv(adresse, port );

    /* Identification */
        req_t reponse;
        recevoir(&client_socket, &reponse, unserial_req);
        printf("Requête reçue : %d - %s - %s\n", reponse.id, reponse.nom, reponse.infos);

        if (reponse.id == 0){

            /* Récupération du pseudo */
            strcpy(pseudo,"");

            while (strlen(pseudo) == 0){
                printf("Saisisez votre pseudo : ");
                scanf("%s", pseudo);

                if (strlen(pseudo) == 0){
                    printf("Votre pseudo est vide");
                }
            }

            // Envoie de la requete d'identification     
            req_t requete = format_req(1, "identification", pseudo);
            envoyer(&client_socket, &requete, serial_req);
            
                            
            reponse.id = -2;
            strcpy(reponse.nom, "");
            strcpy(reponse.infos, "");

            recevoir(&client_socket, &reponse, unserial_req);
            printf("Requête reçue : %d - %s - %s\n", reponse.id, reponse.nom, reponse.infos);

            if (reponse.id == 0){

                printf("Connexion établie \n\n");
                while (1){}
        
            } else {

                printf("Connexion imposible \n\n");
                close(client_socket.fd);
                return 0;
            }
        }

        close(client_socket.fd);
        return 0;
}


/**********************************************************/
// Fonction de requete
/**********************************************************/

req_t format_req(int id, char *nom, char *infos){
    req_t req;
    req.id = id;
    strncpy(req.nom, nom, sizeof(req.nom) - 1);
    strncpy(req.infos, infos, sizeof(req.infos) - 1);
    return req;
}

void serial_req(generic quoi, generic buff){
    req_t *req = (req_t *)quoi;
    sprintf(buff, "%d;%s;%s", req->id, req->nom, req->infos);
}

void unserial_req(generic buff, generic quoi){
    // Cast du paramètre quoi en pointeur vers une structure req_t
    req_t *req = (req_t *)quoi;

    // String de la requête
    char *str_req = (char *)buff;

    // Désérialisation de la requête
    sscanf(str_req, "%d;%99[^;];%99s", &req->id, req->nom, req->infos);
}
